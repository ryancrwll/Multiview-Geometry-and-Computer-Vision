clear all
clc
close all

function [points_3d] = create_set_points(amount)

    points_3d = randi([-480, 480], 3, amount);
end

function print_step(stepNumber)
    % Function to print a formatted step header based on the input number
    disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
    fprintf("       STEP %d\n", stepNumber);
    disp("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(1)

%intrinsic param
au = 557.0943;
av = 712.9824;
u0 = 326.3819;
v0 = 298.6679;
gamma = 0;

%location of tge world ref f in camera coord in mm
Tx = 100;
Ty = 0;
Tz = 1500;

% world rotation w.r.t. camera coord
% euler XYX angle
phix0 = 0.8*pi/2;
phiy0 = -1.8*pi/2;
phix1 = pi/5;

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(2)

% define intrisic parameters K matrix
K = [au gamma u0; 0 av v0; 0 0 1 ];

    % define trasnormation matrix
    % in order to def it we need to def the rotation matrix that is a comp
    % of the rotation in XYX
    Rx0 = [1 0 0 ; 0 cos(phix0) -sin(phix0); 0 sin(phix0) cos(phix0)];
    Ry0 = [cos(phiy0) 0 sin(phiy0); 0 1 0; -sin(phiy0) 0 cos(phiy0)];
    Rx1 = [1 0 0 ; 0 cos(phix1) -sin(phix1); 0 sin(phix1) cos(phix1)];
    
    %calc the rotation matrix from the world to the camera (3x3)
    cRw = Rx0*Ry0*Rx1;

% define the traslation vector of the camera
traslVec = [Tx; Ty; Tz];

disp("Rigid body trasformation of the camera w.e.t. world frame")
cTw = [cRw traslVec; 0 0 0 1]

%define projection matrix P
I3x4 = [1 0 0 0; 0 1 0 0; 0 0 1 0];
P = (K*I3x4)*cTw;
disp("Correct projection matrix")
P = P./P(3,4)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(3)

%
%   3 points have to be no co linar and co planar!!!
%
% def 3 3D points in a range of 480

disp("Created a random set of point in the 3D");
points_3D = create_set_points(6)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(4)

function [points_2D] = from_3D_to_2D(points_3D, P)
    points_2D = [];
    for i=1:length(points_3D)
       Point_i = P*([points_3D(:,i);1]); 
       points_2D = [points_2D, Point_i/(Point_i(3,:))]; 
    end
end

disp("Projection of the points using the given projection matrix");
points_2D = from_3D_to_2D(points_3D, P)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(5)


figure;
scatter(points_2D(1,:), points_2D(2,:));
grid on;
xlabel('X');
ylabel('Y');
title('Points projections');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(6)

function [projection_matrix] = HallMethod(points_2D, points_3D)

    Q = [];
    B = [];
    for i=1:length(points_3D)
        u = points_2D(1,i); v = points_2D(2,i);
        x = points_3D(1,i); y = points_3D(2,i); z = points_3D(3,i);

        %Q_pointi1 = [x y z 1 0 0 0 0 -u*x -u*y -u*z];
        %Q_pointi2 = [0 0 0 0 x y z 1 -v*x -v*y -v*z];
        %Q = [Q; Q_pointi1];
        %Q = [Q; Q_pointi2];
        %B = [B; u];
        %B = [B; v];
        Q_points = [[x y z 1 0 0 0 0 -u*x -u*y -u*z],
                     [0 0 0 0 x y z 1 -v*x -v*y -v*z]];
        Q = [Q; Q_points];
        B = [B; u];
        B = [B; v];
    end
    A = pinv(Q)*B;
    A = [A; 1];
    projection_matrix = [A(1:4)';A(5:8)';A(9:12)'];
end

disp("Estimeted projection matrix using the Hall method");
est_P = HallMethod(points_2D, points_3D)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 7
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(7)

disp("Comparing the values of the two projection matrices (Estimeted P - given P)");
diff_P = abs(est_P-P);
display(diff_P);

%Function given in appendix
function [K,cRw] = get_intrinsics_from_est_P(projection_matrix) 
    % Get left-side 3x3 block of P 
    M = projection_matrix(:,1:3); 
    % This implements the RQ decomposition from QR in matlab 
    [Q,R] = qr(rot90(M,3));    
    R = rot90(R,2)';  
    Q = rot90(Q); 
    % Check the determinant of Q to make cRw a proper rotation 
    if det(Q) < 0 
    cRw = -Q; 
    else 
    cRw = Q; 
    end 
    % Get the normalized intrinsics 
    K = R/R(3,3);
end

[K_hall,cRw_hall] = get_intrinsics_from_est_P(est_P);
disp("Intrinsic parameters of the estimated projection matrix");
display(K_hall);
disp("Rotation matrix of the ccamera using Hall Method");
display(cRw_hall);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 8
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(8)

function [points_2D_wn] = add_noise(points_2D)
    points_2D_wn = points_2D;
    noise = normrnd(0, 0.5, size(points_2D));
    for coloumns = 1:length(points_2D)
        for rows = 1:2
            if randi([0, 100], 1) < 95
                points_2D_wn(rows,coloumns) = noise(rows,coloumns) + points_2D_wn(rows,coloumns);
            end
        end
    end
end

% "_wn" STANDS FOR WITH NOISE

disp("Simulate a noise factor of the projected points in the 2D. (95% of +-1 pixel")
points_2D_wn = add_noise(points_2D);
display(points_2D_wn);

disp("Estimation of the projection matrix using the new set of 2D points with noise")
[est_P_wn] = HallMethod(points_2D_wn, points_3D);
display(est_P_wn);
disp("Comparing the values of the two projection matrices (Estimeted P - given P)");
diff_P = abs(est_P-P);
display(diff_P);
[K_wn, cRw_wn] = get_intrinsics_from_est_P(est_P_wn);
disp("Intrinsic parameters of the estimated projection matrix with noise");
display(K_wn);
disp("Rotation matrix of the ccamera using Hall Method with noise");
display(cRw_wn);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(9)

function [error] = mean_error(points_2D, points_2D_wn)
    distance = [];
    for i=1:length(points_2D)
        distance = [distance, sqrt((points_2D(1,i) - points_2D_wn(1,i))^2 +  (points_2D(2,i) - points_2D_wn(2,i))^2)];
        
    end
    error = mean(distance);  
end

avg_error = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(10)

set_of_points = [6, 10, 50];
n_points = 0;
for i = 1: length(set_of_points)
    points_3D = create_set_points(set_of_points(i));
    points_2D = from_3D_to_2D(points_3D, P);
    points_2D_wn = add_noise(points_2D);
    est_P_wn = HallMethod(points_2D_wn, points_3D);
    disp("Comparing the values of the two projection matrices (Estimeted P - given P)");
    diff_P = abs(est_P_wn-P);
    display(diff_P);
    [K_wn, cRw_wn] = get_intrinsics_from_est_P(est_P_wn);
    fprintf("Intrinsic parameters of the estimated projection matrix with noise of %d amount of points", set_of_points(1, i));
    display(K_wn);
    fprintf("Rotation matrix of the ccamera using Hall Method with noise of %d amount of points", set_of_points(1, i));
    display(cRw_wn);
    new_points_2D_wn = from_3D_to_2D(points_3D, est_P_wn);
    avg_error = [avg_error; mean_error(points_2D, new_points_2D_wn)];
end

figure ;

plot(set_of_points, avg_error, " -o");
grid on
xlabel('Number of points');
ylabel('Average Error');
title('Average Error vs. Set of Points');
grid on;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STEP 11
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
print_step(11)
disp("Step created to understand the result")

% Big set of points's been created to increase the set of points, to see
% the tendency of the system.
avg_error = [];
bigSetPoints = true;
if bigSetPoints
    set_of_big_points = (1:500);
    set_n_points = [];
    
    for i = 1: length(set_of_big_points)
        n_points = 10 + i*5;
        set_n_points(i) = n_points;
        points_3D = create_set_points(n_points);
        points_2D = from_3D_to_2D(points_3D, P);
        points_2D_wn = add_noise(points_2D);
        P_wn = HallMethod(points_2D_wn, points_3D);
        new_points_2D_wn = from_3D_to_2D(points_3D, P_wn);
        avg_error = [avg_error; mean_error(points_2D, new_points_2D_wn)];
    end
    
    disp("Comparing the values of the two projection matrices (Estimeted P - given P)");
    diff_P = abs(est_P_wn-P);
    display(diff_P);

    figure ;
    plot(set_n_points, avg_error);
    grid on;
    xlabel('Number of points');
    ylabel('Average Error');
    title('Average Error vs. Set of Points');
    grid on;
end   

