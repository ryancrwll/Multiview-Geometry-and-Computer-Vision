function LAB3_plotAllStuff(cam1_p2d,cam2_p2d, F, imageSize, color, title1, title2)

if nargin < 4
    title1 = 'Projected points on image plane 1';
    title2 = 'Projected points on image plane 2';
end

% Draw 2D projections on image planes
cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,title1);
cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,title2);
% Draw epipolar lines
[~,~,c1_l_coeff,c2_l_coeff] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400], color);

% Find epipoles constaints
[ep_1, ep_2] = LAB3_findEpipole(F);

% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig, ep_1, ep_2);

end

