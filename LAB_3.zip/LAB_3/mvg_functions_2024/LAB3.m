clear all; close all; clc;

%% Step 1: definition of camera 1 parameters. (World frame = Camera 1 frame).

au1 = 100; av1 = 120; uo1 = 128; vo1 = 128;
imageSize = [256 256];

%% Step 2: definition of camera 2 parameters w.r.t. camera 1/world.

au2 = 90; av2 = 110; uo2 = 128; vo2 = 128; 
ax = 0.1; by = pi/4; cz = 0.2; %[rad] XYZ EULER 
tx = -1000; ty = 190; tz = 230; % camera traslation vector

%% STEP 3: intrinsic matrices and projection matrices

K1 = [au1 0 uo1;0 av1 vo1;0   0   1];% Intrisics matrix for camera 1 

wR1c = eye(3); % rotation of camera 1, from the camera to the world coordinate frame
wt1c = zeros(3,1); % translation of camera 1, from the camera to the world coordinate frame
wT1c = [ wR1c, wt1c; 0 0 0 1]; % Trasformation matrix camera 1 wtp to the world frame

P1 = K1 * [wR1c' -wR1c' * wt1c];

% Note: ************** You have to add your own code from here onward ************

% Intrisics matrix for camera 2
K2 = [au2   0 uo2; 
        0 av2 vo2; 
        0   0   1];

% Rotations matrixes
Rx_ax = [1,       0,          0; 
         0, cos(ax),   -sin(ax); 
         0, sin(ax),    cos(ax)];

Ry_by = [cos(by),  0, sin(by);
               0,  1,       0;
        -sin(by),  0, cos(by)];

Rz_cz = [ cos(cz),   -sin(cz),  0; 
          sin(cz),    cos(cz),  0;
                0,          0,  1];

wR2c = Rx_ax*Ry_by*Rz_cz; % Rotation of camera 2 wrt the camera 1 frame
wt2c = [tx, ty, tz]'; % Traslation of camera 2 wrt the camera 1 frame
wT2c = [ wR2c, wt2c; 0 0 0 1];% Trasformation matrix camera 2 wtp to the camera 1 frame

P2 = K2 * [wR2c' -wR2c' * wt2c];
P2 = P2 ./ P2(3,4); % Normalization

%% STEP 4: compute fondamental matrix analitically

%  skew-symmetric matrix
t21Skew = [   0   -tz    ty; 
             tz     0   -tx; 
            -ty    tx     0];

F_step4 = inv(K2') * wR2c' * t21Skew * inv(K1);  % Fundamental matrix
F_step4 = F_step4./F_step4(3,3); % Normalization

fprintf('Step 4:\n\tAnalytically obtained F:\n');
disp(F_step4);

%% STEP 5: Definition of points wrt the world system reference

V(:,1) = [100;-400;2000];
V(:,2) = [300;-400;3000];
V(:,3) = [500;-400;4000];
V(:,4) = [700;-400;2000];
V(:,5) = [900;-400;3000];
V(:,6) = [100;-40;4000];
V(:,7) = [300;-40;2000];
V(:,8) = [500;-40;3000];
V(:,9) = [700;-40;4000];
V(:,10) = [900;-40;2000];
V(:,11) = [100;40;3000];
V(:,12) = [300;40;4000];
V(:,13) = [500;40;2000];
V(:,14) = [700;40;3000];
V(:,15) = [900;40;4000];
V(:,16) = [100;400;2000];
V(:,17) = [300;400;3000];
V(:,18) = [500;400;4000];
V(:,19) = [700;400;2000];
V(:,20) = [900;400;3000];

%% STEP 6: compute pairs of the points in the images

cam1_p2d = mvg_projectPointToImagePlane(V,P1);
cam2_p2d = mvg_projectPointToImagePlane(V,P2);

%% STEP 7: plot epipole lines and epipole

% it has been created a function to implement this plot
title1 = 'Projected points on image plane 1';
title2 = 'Projected points on image plane 2';
LAB3_plotAllStuff(cam1_p2d, cam2_p2d, F_step4, imageSize, 'b', title1, title2);

%% STEP 8: compute fondamental matrix using 8 points method (without rank 2 costrain)

rank2costr = false; normalizeF = false;
F_step8 = LAB3_computeFondamentalMatrix(cam1_p2d, cam2_p2d, rank2costr, normalizeF);
fprintf('Step 8:\n\tF obtained with 8-points method without imposing rank 2 constrain:\n');
disp(F_step8);

%% STEP 9: compare two F obtained with projection error

[errorVec, meanError] = LAB3_computeProjectionError(cam1_p2d, cam2_p2d, F_step4);
[errorVecComputed, meanErrorComputed] = LAB3_computeProjectionError(cam1_p2d, cam2_p2d, F_step8);

fprintf('Step 9:\n\tMean square error for F analytically computed:\n');
disp(meanError);
fprintf('\n\tMean square error for F 8-points method computed:\n');
disp(meanErrorComputed);

%% STEP 10: plot epipole and epipole lines with the computed F

LAB3_plotAllStuff(cam1_p2d, cam2_p2d, F_step8, imageSize, 'y', 'IMage 1: F matrix without rank 2 without noise', 'IMage 2: F matrix without rank 2 without noise');

%% STEP 11: add zero-mean gaussian noise, range [-1,+1] for a 95% of the points
scale = norminv(0.975);

noise = randn(2, size(cam1_p2d, 2), "double")/ scale; % Add noise
cam1_p2d_wn = cam1_p2d + noise;

noise = randn(2, size(cam2_p2d, 2), "double")/ scale;
cam2_p2d_wn = cam2_p2d + noise;

%% STEP 12: compute F without and with rank 2 costrain using points with noise

% compute F with noise without rank 2 costrain
rank2costr = false; normalizeF = false;
F_step12_1 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-1';
title2 = 'IMAGE 2: with noise+-1';
LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step12_1, imageSize, 'r', title1, title2)

% compute F with noise with rank 2 costrain
rank2costr = true; normalizeF = false;
F_step12_2 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-1 and rank 2';
title2 = 'IMAGE 2: with noise+-1 and rank 2';
LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step12_2, imageSize, 'g', title1, title2)

% find epipoles ith the SDV 
[~, ~, V] = svd(F_step12_2);
ep_1 = V(:,3);
ep_1 = ep_1 ./ ep_1(3,1);
[~, ~, V] = svd(F_step12_2');
ep_2 = V(:,3);
ep_2 = ep_2 ./ ep_2(3,1);


%% STEP 13: add zero-mean gaussian noise, range [-2,+2] for a 95% of the points 
scale_2 = 4/(scale*2);

noise = randn(2, size(cam1_p2d, 2), "double")/ scale_2; % Add noise
cam1_p2d_wn = cam1_p2d + noise;

noise = randn(2, size(cam2_p2d, 2), "double")/ scale_2;
cam2_p2d_wn = cam2_p2d + noise;

% compute F with noise without rank 2 costrain
rank2costr = false; normalizeF = false;
F_step13_1 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-2';
title2 = 'IMAGE 2: with noise+-2';
%LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step13_1, imageSize, 'r', title1, title2)

% compute F with noise with rank 2 costrain
rank2costr = true; normalizeF = false;
F_step13_2 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-2 and rank 2';
title2 = 'IMAGE 2: with noise+-2 and rank 2';
LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step13_2, imageSize, 'g', title1, title2)

%% STEP 14: coordinate normalization

scale_2 = 4/(scale*2);

noise = randn(2, size(cam1_p2d, 2), "double")/ scale_2; % Add noise
cam1_p2d_wn = cam1_p2d + noise;

noise = randn(2, size(cam2_p2d, 2), "double")/ scale_2;
cam2_p2d_wn = cam2_p2d + noise;

% compute F with noise without rank 2 costrain
rank2costr = false; normalizeF = true;
F_step13_1 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-2 and normalization';
title2 = 'IMAGE 2: with noise+-2 and normalization';
%LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step13_1, imageSize, 'r', title1, title2)

% compute F with noise with rank 2 costrain
rank2costr = true; normalizeF = true;
F_step13_2 = LAB3_computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, rank2costr, normalizeF);
title1 = 'IMAGE 1: with noise+-2 with rank 2 and normalization';
title2 = 'IMAGE 2: with noise+-2 with rank 2 and normalization';
LAB3_plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F_step13_2, imageSize, 'g', title1 , title2);




