% This a empty script to help you move faster on you lab work.
clear all;
close all;
clc;

%% Step 1
% defining Camera 1 (Rotation = Identity matrix, Traslation = 0 -> camera 1
% is the origin reference system)
au1 = 100; av1 = 120; uo1 = 128; vo1 = 128;
imageSize = [256 256];

%% Step 2
% Camera 2
au2 = 90; av2 = 110; uo2 = 128; vo2 = 128; 
ax = 0.1; by = pi/4; cz = 0.2; %[rad] XYZ EULER 
tx = -1000; ty = 190; tz = 230; 

% These angles (ax, by, cz) and the traslation vector, defines the position
% of camera 2 with respect of camera 1.

%% STEP 3
% Compute intrinsic matrices and projection matrices

% Identity matrix 3x4
I3x4 = [eye(3), zeros(3,1)];

% Rotations matrixes
Rx_ax = [1,       0,          0; 
         0, cos(ax),   -sin(ax); 
         0, sin(ax),    cos(ax)];

Ry_by = [cos(by),  0, sin(by);
               0,  1,       0;
        -sin(by),  0, cos(by)];

Rz_cz = [ cos(cz),   -sin(cz),  0; 
          sin(cz),    cos(cz),  0;
                0,          0,  1];


% Intrisics matrix for camera 1
K1 = [au1   0 uo1; 
        0 av1 vo1; 
        0   0   1]; 


wR1c = eye(3); % rotation of camera 1, from the camera to the world coordinate frame
wt1c = zeros(3,1); % translation of camera 1, from the camera to the world coordinate frame
wT1c = [ wR1c, wt1c; 0 0 0 1]; % Trasformation matrix camera 1 wtp to the world frame
%P1 = K1 * I3x4 * wT1c; % Projection matrix camera 1

P1 = K1 * [wR1c' -wR1c' * wt1c];
%if P1 (3,4) ~= 1
%    P1 = P1 ./ P1(3,4);
%end

% Note: ************** You have to add your own code from here onward ************
% Intrisics matrix for camera 2
K2 = [au2   0 uo2; 
        0 av2 vo2; 
        0   0   1];

wR2c = Rx_ax*Ry_by*Rz_cz; % Rotation of camera 2 wrt the world frame
wt2c = [tx, ty, tz]'; % Traslation of camera 2 wrt the world frame
wT2c = [ wR2c, wt2c; 0 0 0 1];% Trasformation matrix camera 2 wtp to the world frame

%P2 = K2 * I3x4 * wT2c; % Projection matrix camera 2
P2 = K2 * [wR2c' -wR2c' * wt2c];
P2 = P2 ./ P2(3,4); % Normalization of the P2

%% STEP 4

% Attention: This is an invented matrix just to have some input for the drawing
% functions. You have to compute it properly 

%  skew-symmetric matrix
t21Skew = [   0   -tz    ty; 
             tz     0   -tx; 
            -ty    tx     0];

F = inv(K2') * wR2c' * t21Skew * inv(K1);  % Fundamental matrix
F = F./F(3,3); % Normalization

fprintf('Step 4:\n\tAnalytically obtained F:\n');
disp(F);

%% STEP 5

% Definition of points wrt the world system reference
V(:,1) = [100;-400;2000];
V(:,2) = [300;-400;3000];
V(:,3) = [500;-400;4000];
V(:,4) = [700;-400;2000];
V(:,5) = [900;-400;3000];
V(:,6) = [100;-40;4000];
V(:,7) = [300;-40;2000];
V(:,8) = [500;-40;3000];
V(:,9) = [700;-40;4000];
V(:,10) = [900;-40;2000];
V(:,11) = [100;40;3000];
V(:,12) = [300;40;4000];
V(:,13) = [500;40;2000];
V(:,14) = [700;40;3000];
V(:,15) = [900;40;4000];
V(:,16) = [100;400;2000];
V(:,17) = [300;400;3000];
V(:,18) = [500;400;4000];
V(:,19) = [700;400;2000];
V(:,20) = [900;400;3000];

%% STEP 6
% Projection on image planes

cam1_p2d = mvg_projectPointToImagePlane(V,P1);
cam2_p2d = mvg_projectPointToImagePlane(V,P2);

%% STEP 7
% example of the plotting functions 
% Draw 2D projections on image planes
cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,'Projected points on image plane 1');
cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,'Projected points on image plane 2');

% Draw epipolar lines
[~,~,c1_l_coeff,c2_l_coeff] =  mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400],'b');

% Find epipoles constaints
[ep_1, ep_2] = findEpipole(F);

% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig,ep_1,ep_2);
%% STEP 8
% Compute the fundamental matrix with the 8-point method and SVD
% using of the 2D points obtained in step 6.

F_no2rank = computeFondamentalMatrix(cam1_p2d, cam2_p2d,false, false);
fprintf('Step 8:\n\tF obtained with 8-points method without imposing rank 2 constrain:\n');
disp(F_no2rank);

% Draw 2D projections on image planes
%cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,'Projected points on image plane 1');
%cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,'Projected points on image plane 2');
% Draw epipolar lines
%[~,~,c1_l_coeff,c2_l_coeff] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
%[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400],'y');
% Find epipoles constaints
%[ep_1_no2rank, ep_2_no2rank] = findEpipole(F_no2rank);
% Draw epipoles
%[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig,ep_1_no2rank,ep_2_no2rank);

F_8Points = computeFondamentalMatrix(cam1_p2d, cam2_p2d, true, false);
fprintf('Step 8:\n\tF obtained with 8-points method:\n');
disp(F);


%% STEP 9
% Compare the step 8 matrix with the one obtained in step 4. To obtain a
% value that is representative of the difference, you can use the sum of
% absolute differences or any other indicator that you consider adequate.

[errorVec, meanError] = computeProjectionError(cam1_p2d, cam2_p2d, F);

[errorVec_8, meanError_8] = computeProjectionError(cam1_p2d, cam2_p2d, F_8Points);
%% STEP 10
% Draw in the windows of step 7 all the epipolar geometry, i.e., epipoles
% and epipolar lines by using the matrix obtained in step 8. You can
% represent the location of the epipoles with a cross (‘+’);
% Enlarge the windows if necessary to view the epipoles properly

% Draw 2D projections on image planes
cam1_fig_8 = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,'Projected points on image plane 1');
cam2_fig_8 = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,'Projected points on image plane 2');

% Draw epipolar lines
[~,~,c1_l_coeff_8,c2_l_coeff_8] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F_8Points);
[cam1_fig_8,cam2_fig_8] = mvg_show_epipolar_lines(cam1_fig_8, cam2_fig_8, c1_l_coeff_8,c2_l_coeff_8, [-400,1;300,400],'r');

% Find epipoles constaints
ep_1_8 = [null(F_8Points)]; % Null function return the null space of F, a vector that if moltiplied by F receives 0
ep_1_8 = ep_1_8 ./ep_1_8(3,1); % Normalization 
ep_2_8 = [null(F_8Points')]; % Null function return the null space of F, a vector that if moltiplied by F receives 0
ep_2_8 = ep_2_8 ./ep_2_8(3,1); % Normalization 

% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig_8, cam2_fig_8,ep_1_8,ep_2_8);


%% STEP 11
% Add zero-mean Gaussian noise to the 2D points such that 95% of that
% noise will be the range [−1, +1] pixels.

k = 1;
% Standard deviation for 95% of noise in range [-1, +1]
sigma = k / 1.96;
% Generate noise for each coordinate
noise = sigma * randn(size(cam1_p2d(1:2, :)));

% Add noise to the first two rows (u, v)
cam1_p2d_wn = cam1_fig;
cam1_p2d_wn(1:2, :) = cam1_p2d_wn(1:2, :) + noise;

% Add noise to the first two rows (u, v)
cam1_fig_8_wn = cam1_;
cam1_fig_8_wn(1:2, :) = cam1_fig_wn(1:2, :) + noise;


%% STEP 12
% Compute the fundamental matrix with the 8-point method and SVD
% using of the 2D points obtained in step 6.
F_no2rank = computeFondamentalMatrix(cam1_p2d, cam2_p2d,false, false);
fprintf('Step 8:\n\tF obtained with 8-points method without imposing rank 2 constrain:\n');
disp(F_no2rank);

% Draw 2D projections on image planes
cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,'Projected points on image plane 1');
cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,'Projected points on image plane 2');
% Draw epipolar lines
[~,~,c1_l_coeff,c2_l_coeff] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400],'y');
% Find epipoles constaints
[ep_1_no2rank, ep_2_no2rank] = findEpipole(F_no2rank);
% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig,ep_1_no2rank,ep_2_no2rank);

F_8Points = computeFondamentalMatrix(cam1_p2d, cam2_p2d, true, false);
fprintf('Step 8:\n\tF obtained with 8-points method:\n');
disp(F);

%% STEP 13
% Increase the Gaussian noise of step 11 (now in the range [−2, +2] for
% 95% of points) and repeat steps 8-12.

% Standard deviation for 95% of noise in range [-1, +1]
k = 2;
sigma = k / 1.96;

% Generate noise for each coordinate
noise = sigma * randn(size(cam1_fig(1:2, :)));

% Add noise to the first two rows (u, v)
cam1_fig_wn = cam1_fig;
cam1_fig_wn(1:2, :) = cam1_fig_wn(1:2, :) + noise;

% Add noise to the first two rows (u, v)
cam1_fig_8_wn = cam1_fig_8;
cam1_fig_8_wn(1:2, :) = cam1_fig_wn(1:2, :) + noise;


% Compute the fundamental matrix with the 8-point method and SVD
% using of the 2D points obtained in step 6.
F_no2rank = computeFondamentalMatrix(cam1_p2d, cam2_p2d,false, false);
fprintf('Step 8:\n\tF obtained with 8-points method without imposing rank 2 constrain:\n');
disp(F_no2rank);

% Draw 2D projections on image planes
cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,'Projected points on image plane 1');
cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,'Projected points on image plane 2');
% Draw epipolar lines
[~,~,c1_l_coeff,c2_l_coeff] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400],'y');
% Find epipoles constaints
[ep_1_no2rank, ep_2_no2rank] = findEpipole(F_no2rank);
% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig,ep_1_no2rank,ep_2_no2rank);

F_8Points = computeFondamentalMatrix(cam1_p2d, cam2_p2d, true, false);
fprintf('Step 8:\n\tF obtained with 8-points method:\n');
disp(F);
%% STEP 14

return;

[U,S,V] = svd(F);
S(3,3) = 0;
F_rank2 = U*S*V';

null(F_rank2)