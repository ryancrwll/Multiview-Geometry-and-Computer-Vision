function [errorVec, meanError] = computeProjectionError(cam1_p2d,cam2_p2d, F)

% Ensure input is in homogeneous coordinates
if size(cam1_p2d, 1) == 2
    cam1_p2d = [cam1_p2d; ones(1, size(cam1_p2d, 2))];
end
if size(cam2_p2d, 1) == 2
    cam2_p2d = [cam2_p2d; ones(1, size(cam2_p2d, 2))];
end

n = size(cam1_p2d, 2);

errorVec = zeros(n, 1);
for i = 1 : size(cam1_p2d, 2)

   errorVec(i) = cam2_p2d(:,i)'* F * cam1_p2d(:,i);
end

meanError = mean(errorVec);

