function plotAllEpipole(cam1_p2d,cam2_p2d, F, title1, title2)

if nargin < 4
    title1 = "no title";
    title2 = "no title";
end

% Draw 2D projections on image planes
cam1_fig = mvg_show_projected_points(cam1_p2d(1:2,:),imageSize,title1);
cam2_fig = mvg_show_projected_points(cam2_p2d(1:2,:),imageSize,title2);

% Draw epipolar lines
[~,~,c1_l_coeff,c2_l_coeff] = mvg_compute_epipolar_geom_modif(cam1_p2d,cam2_p2d,F);
[cam1_fig,cam2_fig] = mvg_show_epipolar_lines(cam1_fig, cam2_fig, c1_l_coeff,c2_l_coeff, [-400,1;300,400],'y');


% Find epipoles constaints
[ep_1_no2rank, ep_2_no2rank] = findEpipole(F_no2rank);

% Draw epipoles
[~,~] = mvg_show_epipoles(cam1_fig, cam2_fig,ep_1_no2rank,ep_2_no2rank);

end