function [ep_1,ep_2] = LAB3_findEpipole(F)

ep_1 = zeros(3,1);
ep_2 = zeros(3,1);

if rank(null(F)) == 0
    disp("Null function of the fondamental matrix is empty")

    return
end

ep_1 = [null(F)]; % Null space of F
ep_1 = ep_1 ./ep_1(3,1); % Normalization 
ep_2 = [null(F')]; % Null space of F
ep_2 = ep_2 ./ep_2(3,1); % Normalization 
end