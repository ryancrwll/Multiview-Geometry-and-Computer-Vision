function [F] = LAB3_computeFondamentalMatrix(cam1_p2d,cam2_p2d, rankConstrain, normalize)

if nargin < 3
    rankConstrain = true;
end 
if nargin < 4
    normalize = true;
end
%%
% Ensure input is in homogeneous coordinates
if size(cam1_p2d, 1) == 2
    cam1_p2d = [cam1_p2d; ones(1, size(cam1_p2d, 2))];
end
if size(cam2_p2d, 1) == 2
    cam2_p2d = [cam2_p2d; ones(1, size(cam2_p2d, 2))];
end

n = size(cam1_p2d, 2);

%% 8-points method
if normalize
    % Normalize input points
    [cam1_p2d, T1] = LAB3_normalizePoints2D(cam1_p2d);
    [cam2_p2d, T2] = LAB3_normalizePoints2D(cam2_p2d);
end

U_n = zeros(n, 9);
for i = 1: n
    % applying Hall Method
    u1 = cam1_p2d(1, i); v1 = cam1_p2d(2, i);
    u2 = cam2_p2d(1, i); v2 = cam2_p2d(2,i);
    U_n(i, :) = [u2*u1, u2*v1, u2, v2*u1, v2*v1, v2, u1, v1, 1];
end
text = "Condition number of the Un matrix ";
if normalize
    text = text + "with normalization";
else 
    text = text + "without normalization";
end
disp(text)
display(cond(U_n))

[~, ~, V] = svd(U_n); % Solve using SVD
F = reshape(V(:,9),3,3)'; % Extract F matrix from the column of V 


if rankConstrain
    [U,D,V] = svd(F); % Singular Value Decomposition
    F = U*diag([D(1,1) D(2,2) 0])*V'; % Enforce rank2 constraint
end
F = F ./ F(3,3); % Normalization

if normalize
    % Denormalize the fundamental matrix
    F = T2' * F * T1;
end


end
 

