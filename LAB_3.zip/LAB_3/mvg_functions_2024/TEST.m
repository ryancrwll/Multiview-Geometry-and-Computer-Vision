clear all;
close all;
clc;
V(:,1) = [100;-400;2000];
V(:,2) = [300;-400;3000];
V(:,3) = [500;-400;4000];
V(:,4) = [700;-400;2000];
V(:,5) = [900;-400;3000];
V(:,6) = [100;-40;4000];
V(:,7) = [300;-40;2000];
V(:,8) = [500;-40;3000];
V(:,9) = [700;-40;4000];
V(:,10) = [900;-40;2000];
V(:,11) = [100;40;3000];
V(:,12) = [300;40;4000];
V(:,13) = [500;40;2000];
V(:,14) = [700;40;3000];
V(:,15) = [900;40;4000];
V(:,16) = [100;400;2000];
V(:,17) = [300;400;3000];
V(:,18) = [500;400;4000];
V(:,19) = [700;400;2000];
V(:,20) = [900;400;3000];


au1 = 100; av1 = 120; uo1 = 128; vo1 = 128;
imageSize = [256 256];

au2 = 90; av2 = 110; uo2 = 128; vo2 = 128; 
ax = 0.1; by = pi/4; cz = 0.2; %[rad] XYZ EULER 
tx = -1000; ty = 190; tz = 230; 

I3x4 = [eye(3), zeros(3,1)];
Rx_ax = [1,       0,          0;       0, cos(ax),   -sin(ax); 0, sin(ax),    cos(ax)];
Ry_by = [cos(by),  0, sin(by);0,  1,       0;-sin(by),  0, cos(by)];
Rz_cz = [ cos(cz),   -sin(cz),  0; sin(cz),    cos(cz),  0;0,          0,  1];

K1 = [au1   0 uo1; 0 av1 vo1; 0   0   1]; 

wR1c = eye(3); % rotation of camera 1, from the camera to the world coordinate frame
wt1c = zeros(3,1); % translation of camera 1, from the camera to the world coordinate frame
wT1c = [ wR1c, wt1c; 0 0 0 1]; % Trasformation matrix camera 1 wtp to the world frame

P1 = K1 * [wR1c' -wR1c' * wt1c];

K2 = [au2   0 uo2; 0 av2 vo2; 0   0   1];

wR2c = Rx_ax*Ry_by*Rz_cz; % Rotation of camera 2 wrt the world frame
wt2c = [tx, ty, tz]'; % Traslation of camera 2 wrt the world frame
wT2c = [ wR2c, wt2c; 0 0 0 1];% Trasformation matrix camera 2 wtp to the world frame

P2 = K2 * [wR2c' -wR2c' * wt2c];
P2 = P2 ./ P2(3,4); % Normalization of the P2

t21Skew = [   0   -tz    ty; tz     0   -tx;-ty    tx     0];

cam1_p2d = mvg_projectPointToImagePlane(V,P1);
cam2_p2d = mvg_projectPointToImagePlane(V,P2);


%% original F
F = inv(K2') * wR2c' * t21Skew * inv(K1); 
F = F./F(3,3); 

%% first F without noise
F = computeFondamentalMatrix(cam1_p2d, cam2_p2d,false, false);

%% noise 1 generation
scale = 1.96;
noise = randn(2, size(cam1_p2d, 2), "double")/ scale;
cam1_p2d_wn = cam1_p2d + noise;
noise = randn(2, size(cam2_p2d, 2), "double")/ scale;
cam2_p2d_wn = cam2_p2d + noise;

%% F with noise without rank 2 costrain
F = computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, false, false);

%% F with noise
F = computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, true, false);

%% noise 2
scale = scale * 2;
noise = randn(2, size(cam1_p2d, 2), "double")/ scale;
cam1_p2d_wn = cam1_p2d + noise;
noise = randn(2, size(cam2_p2d, 2), "double")/ scale;
cam2_p2d_wn = cam2_p2d + noise;

%% F with noise without rank 2 costrain normalized
F = computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, false, false);

%% F with noise normalized
F = computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, false, false);



%%
scale = 1.02;
noise = randn(2, size(cam1_p2d, 2), "double")/ scale;
cam1_p2d_wn = cam1_p2d + noise;
noise = randn(2, size(cam2_p2d, 2), "double")/ scale;
cam2_p2d_wn = cam2_p2d + noise;
F = computeFondamentalMatrix(cam1_p2d_wn, cam2_p2d_wn, true, false);
plotAllStuff(cam1_p2d_wn, cam2_p2d_wn, F, imageSize, 'y', 'im1', 'im2');

