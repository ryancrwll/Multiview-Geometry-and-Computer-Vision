function [ep_1,ep_2] = findEpipole(F)

ep_1 = [null(F)]; % Null function return the null space of F, a vector that if moltiplied by F receives 0
ep_1 = ep_1 ./ep_1(3,1); % Normalization 
ep_2 = [null(F')]; % Null function return the null space of F, a vector that if moltiplied by F receives 0
ep_2 = ep_2 ./ep_2(3,1); % Normalization 
end