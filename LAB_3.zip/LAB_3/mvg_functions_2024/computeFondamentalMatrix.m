function [F] = computeFondamentalMatrix(cam1_p2d,cam2_p2d, rankConstrain, normalise)

if nargin < 3
    rankConstrain = true;
end 
if nargin < 4
    normalise = true;
end

% Ensure input is in homogeneous coordinates
if size(cam1_p2d, 1) == 2
    cam1_p2d = [cam1_p2d; ones(1, size(cam1_p2d, 2))];
end
if size(cam2_p2d, 1) == 2
    cam2_p2d = [cam2_p2d; ones(1, size(cam2_p2d, 2))];
end

n = size(cam1_p2d, 2);

% 9-points 
if normalise
    % Normalize input points
    [cam1_p2d, T1] = normalizePoints2D(cam1_p2d);
    [cam2_p2d, T2] = normalizePoints2D(cam2_p2d);
end
U_n = zeros(n, 9);
for i = 1: n
    u1 = cam1_p2d(1, i); v1 = cam1_p2d(2, i);
    u2 = cam2_p2d(1, i); v2 = cam2_p2d(2,i);
    U_n(i, :) = [u2*u1, u2*v1, u2, v2*u1, v2*v1, v2, u1, v1, 1];
end
% Solve using SVD
[U, D, V] = svd(U_n);
% Extract fundamental matrix from the column of V
% corresponding to the smallest singular value.
F = reshape(V(:,9),3,3)';

% Enforce rank2 constraint
if rankConstrain
    
    [U,D,V] = svd(F);
    F = U*diag([D(1,1) D(2,2) 0])*V';
end

if normalise
    % Denormalize the fundamental matrix
    F = T2' * F * T1;
end

F = F ./ F(3,3);
end
 

