function [normPoints, T] = normalizePoints2D(points)
    % Normalize 2D points for numerical stability

    % Compute centroid
    centroid = mean(points(1:2, :), 2);
    % Translate points to have centroid at origin
    translatedPoints = points(1:2, :) - centroid;
    % Compute scale (average distance from origin should be sqrt(2))
    avgDist = mean(sqrt(sum(translatedPoints.^2, 1)));
    scale = sqrt(2) / avgDist;
    % Construct normalization matrix
    T = [scale,    0, -scale * centroid(1);
         0,    scale, -scale * centroid(2);
         0,       0,                1];
    % Apply normalization
    normPoints = T * points;
end